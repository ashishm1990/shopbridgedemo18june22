﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ShopBridgeAPI.Models
{
    public class ShopAPIRepository : IShopAPIRepository
    {
        string connstring= ConfigurationManager.ConnectionStrings["conn"].ToString();
        public IEnumerable<ShopAPI> GetAll()
        {
            List<ShopAPI> Item = new List<ShopAPI>();
            using (SqlConnection con =new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("GetList", con))
                {
                    con.Open();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", 0);
                    cmd.Parameters.AddWithValue("@FlagList", 1);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ShopAPI item = new ShopAPI();
                        item.Id = reader.GetInt32(0);
                        item.Name = reader.GetString(1);
                        item.Description = reader.GetString(2);
                        item.Price = reader.GetDouble(3);

                        Item.Add(item);
                    }
                    con.Close();
                }
            }
            return Item.ToArray();
        }

        public string AddUpdatedelete(ShopAPI item)
        {
            string str = "";
            using (SqlConnection con =new SqlConnection(connstring))
            {
                using (SqlCommand cmd = new SqlCommand("AddInventory", con))
                {
                    con.Open();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", item.Id);
                    cmd.Parameters.AddWithValue("@Name", item.Name);
                    cmd.Parameters.AddWithValue("@Description", item.Description);
                    cmd.Parameters.AddWithValue("@Price", item.Price);
                    cmd.Parameters.AddWithValue("@Flag", item.flag);
                    SqlParameter sqlParam = new SqlParameter("@Str", System.Data.SqlDbType.NVarChar, 1000);
                    sqlParam.Direction = System.Data.ParameterDirection.Output;
                    cmd.Parameters.Add(sqlParam);
                    cmd.ExecuteNonQuery();

                    str = sqlParam.Value.ToString();
                    con.Close();
                }
            }

            return str;
        }
    }
}