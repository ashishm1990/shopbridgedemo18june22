﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridgeAPI.Models
{
    interface IShopAPIRepository
    {
        IEnumerable<ShopAPI> GetAll();
        string AddUpdatedelete(ShopAPI item);

    }
}
