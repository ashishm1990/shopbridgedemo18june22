﻿using ShopBridgeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ShopBridgeAPI.Controllers
{
    public class ShopAPIController : ApiController
    {
        static readonly IShopAPIRepository repository = new ShopAPIRepository ();

        public IEnumerable<ShopAPI> GetAllInventoryDtls()
        {
            return repository.GetAll();
        }
        

        public string AddInventory(ShopAPI item)
        {
            string msg = repository.AddUpdatedelete(item).ToString();
            var response = Request.CreateResponse<ShopAPI>(HttpStatusCode.Created, item);

            return msg;
        }
    }
}
